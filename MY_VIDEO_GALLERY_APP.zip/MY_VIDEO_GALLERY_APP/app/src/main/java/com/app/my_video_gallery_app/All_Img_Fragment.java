package com.app.my_video_gallery_app;


import static android.app.Activity.RESULT_OK;


import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;


import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.VideoView;


public class All_Img_Fragment extends Fragment {



    VideoView videoView;
    Button LoadVid;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        View view = inflater.inflate(R.layout.fragment_all__img_, container, false);
        videoView = view.findViewById(R.id.videoView);
        LoadVid=view.findViewById(R.id.LoadVid);

        LoadVid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, 0);
            }
        });


        return view;

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Uri video = data.getData();
            videoView.setVideoURI(video);
            videoView.start();
        }
    }
}








